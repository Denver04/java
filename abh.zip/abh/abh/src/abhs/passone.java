package abhs;

public class passone {

}
